# Uppgift 7

Validera ett lösenord

## Beskrivning

Skapa en funktion validate_password(password) som kontrollerar att lösenordet är minst 8 tecken långt och innehåller minst en siffra.
