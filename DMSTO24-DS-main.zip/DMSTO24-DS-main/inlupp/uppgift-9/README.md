# Uppgift 9

Palindromkontroll

## Beskrivning

Skapa en funktion is_palindrome(string) som kontrollerar om en given sträng är ett palindrom (dvs. samma framifrån och bakifrån).
