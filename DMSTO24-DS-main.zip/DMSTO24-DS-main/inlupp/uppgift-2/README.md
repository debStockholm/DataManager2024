# Uppgift 2

Summera alla siffror i en lista

## Beskrivning

Skapa en funktion sum_list(numbers) som returnerar summan av alla siffror i listan.

### Funktionens Signatur

```python
def sum_list(numbers: List[int]) -> int:
    """
    Returnerar summan av alla siffror i listan.
    """
    pass # Ta bort denna rad och skriv din kod här
```
