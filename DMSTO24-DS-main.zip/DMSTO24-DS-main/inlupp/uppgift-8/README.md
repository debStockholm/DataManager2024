# Uppgift 8

Räkna förekomsten av bokstäver

## Beskrivning

Skapa en funktion count_letters(string) som returnerar en dictionary med varje bokstav som nyckel och antalet förekomster som värde.
