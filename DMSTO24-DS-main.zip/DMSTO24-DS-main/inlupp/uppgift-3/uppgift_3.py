# Uppgift 3
# Hitta det största talet i en lista

def funktions_namn(variabel_namn: datatyp) -> returtyp:
    """
    Skriv beskrivning här.
    """
    pass # Ta bort denna rad och skriv din kod här
