# Uppgift 3

Hitta det största talet i en lista

## Beskrivning

Skapa en funktion max_in_list(numbers) som returnerar det största talet i listan.

### Funktionens Signatur

```python
def max_in_list(numbers: List[int]) -> int:
    """
    Returnerar det största talet i listan.
    """
    pass # Ta bort denna rad och skriv din kod här
```
