# Uppgift 1

Skapa en funktion is_odd(x) som returnerar True om x är udda och False om x är jämnt.

## Beskrivning

Skapa en funktion `is_odd(x: int) -> bool` som returnerar True om x är udda och False om x är jämnt.

### Funktionens Signatur

```python
def is_odd(x: int) -> bool:
    """
    Returnerar True om x är udda, annars False.
    """
    pass # Ta bort denna rad och skriv din kod här
```
