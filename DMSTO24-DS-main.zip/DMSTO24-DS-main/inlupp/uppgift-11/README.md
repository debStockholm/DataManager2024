# Uppgift 11

Räkna orden i en text

## Beskrivning

Skapa en funktion word_count(text) som returnerar antalet ord i en given text.
