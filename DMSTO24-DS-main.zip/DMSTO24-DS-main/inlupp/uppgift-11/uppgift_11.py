# Uppgift 11
# Skapa en funktion word_count(text) som returnerar antalet ord i en given text.

def funktions_namn(variabel_namn: datatyp) -> returtyp:
    """
    Skriv beskrivning här.
    """
    pass # Ta bort denna rad och skriv din kod här
