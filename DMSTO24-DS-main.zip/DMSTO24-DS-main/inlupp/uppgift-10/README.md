# Uppgift 10

Konvertera celsius till fahrenheit

## Beskrivning

Skapa en funktion celsius_to_fahrenheit(celsius) som konverterar en temperatur från Celsius till Fahrenheit.
