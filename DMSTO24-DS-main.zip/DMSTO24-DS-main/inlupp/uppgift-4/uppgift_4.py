# Uppgift 4
# Skapa en funktion fibonacci(n) som returnerar en lista med de första n Fibonacci-talen.

def funktions_namn(variabel_namn: datatyp) -> returtyp:
    """
    Skriv beskrivning här.
    """
    pass # Ta bort denna rad och skriv din kod här
