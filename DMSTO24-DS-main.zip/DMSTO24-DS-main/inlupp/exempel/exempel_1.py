
def is_even(number: int) -> bool:
    """
    Returnerar True om talet är jämnt, annars False.
    """
    return number % 2 == 0
    


