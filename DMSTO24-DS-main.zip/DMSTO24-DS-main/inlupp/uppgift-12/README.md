# Uppgift 12

Lagra data i en dictionary

## Beskrivning

Skapa en funktion create_student_register(students) som tar emot en lista med namn och ålder och returnerar en dictionary där namnet är nyckeln och åldern är värdet.

