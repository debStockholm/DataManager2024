# Uppgift 6
# Skapa en funktion multiplication_table(n, limit) som returnerar multiplikationstabellen för n upp till limit i en lista.

def funktions_namn(variabel_namn: datatyp) -> returtyp:
    """
    Skriv beskrivning här.
    """
    pass # Ta bort denna rad och skriv din kod här
