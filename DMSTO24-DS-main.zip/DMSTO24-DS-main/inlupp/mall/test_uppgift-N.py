from uppgift_N import funktion

def test_funktion():
    assert funktion("Hej") == True


