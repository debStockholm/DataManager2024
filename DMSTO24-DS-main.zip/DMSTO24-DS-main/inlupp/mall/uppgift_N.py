# Uppgift N
# Skapa en funktion som 

def funktion(x: str) -> bool:
    """
    Kort beskrivning...
    """
    return True # Returnerar True om...
