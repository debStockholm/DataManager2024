
x = 0.1 + 0.2

print(x)

x = 10
y = 3

# (+, -, *, /, //, %, **)
print(x + y)
print(x - y)
print(x * y)
print(x / y)
print(x // y)
print(x % y)
print(x ** y)


pi = 3.14
print(int(pi))
x = int(pi)
print(x)

heltal = 5
y = float(heltal)
print(y)

resultat = round(0.00012 + 0.00018, 4)  # Avrunda till 1 decimal
print(resultat)  # Output: 0.3


# tal1 = 0.1
# tal2 = 0.2
# tal1 = int(tal1 * 10)
# tal2 = int(tal2 * 10)
# print(tal1 + tal2)

# korrektSvar = (tal1 + tal2) / 10

# print(korrektSvar)
