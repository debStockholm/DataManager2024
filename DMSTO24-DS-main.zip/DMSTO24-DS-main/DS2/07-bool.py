
x = True
y = False
print(type(x))  # Output: <class 'bool'>
