
namn = "Anna"
my_age = 25

print(f"Vad heter du? {namn}, Hur gammal är du? {my_age}")

sanning = False

if sanning == True:
    print("Fel indentering")  # IndentationError
if sanning == False:
    print("Rätt indentering")  # IndentationError

