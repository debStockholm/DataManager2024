
a = 5 + 3
b = 5 // 2  # Heltalsdivision
c = 5 % 2   # Resten vid division
d = 5 ** 2  # 5 upphöjt till 2
print(a, b, c, d)

x = 42.6
y = int(x)

print(y)

z = round(x)
print(z)

