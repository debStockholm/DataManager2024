
# heltal = 10
# flyttal = 3.14
# text = "Python är roligt"
# sanningsvärde = True

# print(type(heltal))
# print(type(flyttal))
# print(type(text))
# print(type(sanningsvärde))

x = "123"
y = 2
z = int(x) * y
print(z)

