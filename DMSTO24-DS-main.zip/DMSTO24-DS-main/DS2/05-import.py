from decimal import Decimal

x = Decimal('0.1') + Decimal('0.2')

print(x)


