var reallyLongList = [
  'äpple',
  'banan',
  'körsbär',
  'druva',
  'apelsin',
  'päron',
  'kiwi',
  'mango',
  'passionsfrukt',
  'ananas',
];

for (var i = 0; i < reallyLongList.length; i + 3) {}
