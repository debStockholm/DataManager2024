

# # Skapa ett program som kollar om ett tal är jämnt eller udda.
# while True:
#     x = int(input("Skriv ett tal: "))
#     if x == 0:
#         print(f'{x} är noll.')
#         break
#     elif x % 2 == 0:
#         print(f'{x} är ett jämnt tal.')
#     else:
#         print(f'{x} är ett udda tal.')

# # Skapa en loop som skriver ut alla siffror mellan 1 och 10.
# for iter in range(1, 11):
#     print(iter)

# x = 1
# for x in 10:

# x = 1
# while x < 11: 
#     print(x)
#     x = x + 0.5


# Skapa en while-loop som räknar ned från 10 till 1 och skriver "Starta!" när den är klar.
i = 10
while i > 0:
    print(i)
    i -= 1

print("Starta!")

# # Eller

i = -10
while i > 0:
    print(i)
    i -= 1
else:
    print("i är mindre än 0")
print("Starta!")

