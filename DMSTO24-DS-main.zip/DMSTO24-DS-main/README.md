# Data Manager Stockholm24 - Data Science

Föreläsningsexempel hittar du i mappen för varje föreläsning. Jag laddar upp löpande under kursens gång.

## Inlämningsuppgifter

Instruktioner hittar du i mappen `inlupp`.

[Instruktioner för inlämningsuppgifter](inlupp/README.md)


## Git instruktioner

Se [Git-intro](git-intro.md) för att komma igång med Git.

